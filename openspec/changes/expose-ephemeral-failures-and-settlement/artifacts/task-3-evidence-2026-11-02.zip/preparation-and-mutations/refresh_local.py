from pathlib import Path
import subprocess, json, re, hashlib, shutil

root = Path(__file__).resolve().parents[3]
mirror = Path('E:/oc16s')
def git(*args): return subprocess.check_output(['git', *args],cwd=root)
def write(path, text): path.write_text(text,encoding='utf-8',newline='\n')
def changed(): return sorted(set(git('diff','--name-only','HEAD').decode().splitlines()+git('ls-files','--others','--exclude-standard').decode().splitlines()))
def normalize():
    for name in git('diff','--name-only','HEAD').decode().splitlines():
        path=root/name
        before=git('show','HEAD:'+name)
        newline=b'\r\n' if b'\r\n' in before else b'\n'
        if name.endswith('section-07-r-declaration-crosswalk.json'): newline=b'\n'
        path.write_bytes(path.read_bytes().replace(b'\r\n',b'\n').replace(b'\n',newline))

cross=root/'tests/OrcaCore.DeveloperSurface.Guards/Fixtures/section-07-r-declaration-crosswalk.json'
record=json.loads(cross.read_text(encoding='utf-8'))
pattern=re.compile(r'^\s*\[(?:Fact|Theory)(?:Attribute)?(?:\([^\]]*\))?\](?:\s*\[[^\]]+\])*\s*(?:(?:public|private|internal|protected|static|async|virtual|override|sealed|new)\s+)+[^\r\n({;=]+\s+(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*\(',re.M|re.S)
for row in record['sourceInventory']:
    row['declarations']=len(pattern.findall((root/row['source']).read_text(encoding='utf-8-sig')))
counts=record['accounting']
counts['physicalDeclarations']=sum(row['declarations'] for row in record['sourceInventory'])
counts['activeDeclarations']=sum(row['declarations'] for row in record['sourceInventory'] if row['status']=='active')
write(cross,json.dumps(record,indent=2)+'\n')
guard=root/'tests/OrcaCore.DeveloperSurface.Guards/RecoveryCrosswalkGuards.cs'
write(guard,re.sub(r'expected\["activeDeclarations"\]\.Should\(\)\.Be\(\d+\)',f'expected["activeDeclarations"].Should().Be({counts["activeDeclarations"]})',guard.read_text(encoding='utf-8')))
tasks=root/'openspec/changes/reshape-developer-facing-interfaces/tasks.md'
text=tasks.read_text(encoding='utf-8')
text=re.sub(r'at 374 sources / [\d,]+ declarations',f'at 374 sources / {counts["physicalDeclarations"]:,} declarations',text)
text=text.replace('the issue #16 canonical-transition infrastructure controls','the issue #16 canonical-transition and failure/settlement source controls')
write(tasks,text)
normalize()
auth=root/'openspec/changes/expose-ephemeral-failures-and-settlement/artifacts/task-3-source-authorization-2026-11-02.json'
record=json.loads(auth.read_text(encoding='utf-8'))
for name,row in record['sourceFiles'].items(): row['afterSha256']=hashlib.sha256((root/name).read_bytes()).hexdigest()
write(auth,json.dumps(record,indent=2)+'\n')
guard=root/'tests/OrcaCore.DeveloperSurface.Guards/EphemeralFailureSettlementSourceGuards.cs'
write(guard,re.sub(r'private const string RegistryHash = "[a-f0-9]+";',f'private const string RegistryHash = "{hashlib.sha256(auth.read_bytes()).hexdigest()}";',guard.read_text(encoding='utf-8')))
normalize()
for name in changed():
    destination=mirror/name
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root/name,destination)
print(json.dumps(dict(physicalDeclarations=counts['physicalDeclarations'],activeDeclarations=counts['activeDeclarations'],sourcePaths=len(record['sourceFiles']),mirroredPaths=len(changed())),indent=2))
