from pathlib import Path
import hashlib, json, subprocess, time, xml.etree.ElementTree as ET

repo = Path('E:/oc16s')
out = Path(__file__).resolve().parent / "runtime-mutation-reviewed"
out.mkdir(exist_ok=True)
products = {
    'adapter': 'src/OrcaCore.Engine.Ephemeral/Execution/InMemoryExecutionStateAdapter.cs',
    'failure': 'src/OrcaCore.Engine.Ephemeral/Execution/InMemoryExecutionStateAdapter.Failures.cs',
    'instance': 'src/OrcaCore.Engine.Ephemeral/Execution/WorkflowInstance.cs',
    'merge': 'src/OrcaCore.Engine.Ephemeral/Execution/InMemoryExecutionStateAdapter.Merge.cs',
    'lifetime': 'src/OrcaCore.Engine.Ephemeral/Execution/EphemeralInstanceLifetime.cs',
    'codec': 'src/OrcaCore.Abstractions/Serialization/WorkflowFailureJsonConverters.cs',
    'fiber': 'src/OrcaCore.Core/Execution/FiberModel.cs',
    'facade': 'src/OrcaCore.Abstractions/Facades/WorkflowFacadeContracts.cs',
    'registry': 'src/OrcaCore.Engine.Ephemeral/Facade/EphemeralWorkflowFacade.cs',
    'dispatch': 'src/OrcaCore.Core/Execution/StructuredInvocationCache.cs',
}
originals = {key: (repo / path).read_bytes() for key, path in products.items()}

def replace(key, before, after, count=1):
    path = repo / products[key]
    data = path.read_bytes()
    assert data.count(before.encode()) >= count, (key, before)
    path.write_bytes(data.replace(before.encode(), after.encode(), count))

ephemeral = ('Engine.Ephemeral', 'OriginalStepFailureTests')
codec = ('Core', 'WorkflowFailureCodecAmendmentTests')
mutants = [
    ('abort-unrelated-branch-cancellation', ('Engine.Ephemeral', 'UnrelatedBranchOrItemCancellation'), [('dispatch', '(error is not OperationCanceledException cancelled || !cancellationToken.IsCancellationRequested || cancelled.CancellationToken != cancellationToken)', 'error is not OperationCanceledException')]),
    ('retain-runtime-in-handle', ('Engine.Ephemeral', 'RetiredReceiptHandle_DoesNotKeepItsDisposedDependencyGraphAlive'), [('registry', 'var address = binding with { Runtime = null };', 'var address = binding;', 2)]),
    ('retain-registry-after-release', ('Engine.Ephemeral', 'RetiredReceiptHandle_DoesNotKeepItsDisposedDependencyGraphAlive'), [('registry', 'Volatile.Write(ref registry, null);', '// mutation: retain registry')]),
    ('retain-handle-owner-after-dispose', ('Engine.Ephemeral', 'RetiredReceiptHandle_DoesNotKeepItsDisposedDependencyGraphAlive'), [('registry', 'binding.Access.Release(retired: false);', '_ = binding;')]),
    ('discard-original', ephemeral, [('adapter', 'originalStepFailure = business.InnerException', 'originalStepFailure = null')]),
    ('wrong-non-orca-code', ephemeral, [('failure', 'known.Code : "WF-STEP-UNHANDLED"', 'known.Code : "WF-LEGACY-LIFECYCLE"')]),
    ('discard-type', ephemeral, [('adapter', 'exceptionType: originalStepFailure is null ? null : originalStepFailure.GetType().FullName ?? originalStepFailure.GetType().Name', 'exceptionType: null')]),
    ('unwrap-user-invocation', ephemeral, [
        ('failure', 'new BusinessStepException(error)', 'new BusinessStepException(error is System.Reflection.TargetInvocationException { InnerException: { } inner } ? inner : error)'),
        ('adapter', 'new BusinessStepException(error)', 'new BusinessStepException(error is System.Reflection.TargetInvocationException { InnerException: { } inner } ? inner : error)')]),
    ('retain-recovered-original', ephemeral, [('merge', 'instance.ForgetOriginals(', '_ = (')]),
    ('retain-retired-slot', ephemeral, [('instance', 'OriginalFailure = null;', '// mutation: retain the retired slot')]),
    ('settle-nonterminal', ('Engine.Ephemeral', 'IdleIsNotSettlement_ObserversCancelLocally'), [('lifetime', 'if (accepted && terminal && owned == 0)', 'if (accepted && owned == 0)')]),
    ('settle-before-physical-return', ('Engine.Ephemeral', 'LogicalTimeout_DoesNotSettleBlockedPhysicalWork'), [('lifetime', 'if (accepted && terminal && owned == 0)', 'if (accepted && terminal)')]),
    ('allow-work-after-proof', ('Engine.Ephemeral', 'Receipt_DoesNotWaitForQueryPin_'), [('lifetime', 'if (retired || finalSettlement.Task.IsCompleted) { lease = null; return false; }', 'if (retired) { lease = null; return false; }')]),
    ('allow-callback-after-proof', ('Engine.Ephemeral', 'Receipt_DoesNotWaitForQueryPin_'), [('lifetime', 'if (retired || finalSettlement.Task.IsCompleted) { ownership = null; return false; }', 'if (retired) { ownership = null; return false; }')]),
    ('write-wrong-version', codec, [('codec', 'writer.WriteNumber("version", 2)', 'writer.WriteNumber("version", 1)')]),
    ('write-wrong-type', codec, [('codec', 'writer.WriteString("exceptionType", value.ExceptionType)', 'writer.WriteString("exceptionType", "Wrong.Type")')]),
    ('change-legacy-wire', codec, [('codec', 'if (value.ExceptionType is not null) writer.WriteNumber("version", 2);', 'writer.WriteNumber("version", 2);')]),
    ('allow-extra-duplicate-properties', codec, [('codec', 'if (properties.Length != names.Length || !properties.ToHashSet(StringComparer.Ordinal).SetEquals(names))', 'if (properties.Length < 0)')]),
    ('accept-old-typed-version', codec, [('codec', 'format != 2', 'format < 0')]),
    ('capture-durable-type', ('Engine.Durable', 'DurableFailureProvenanceTests'), [('fiber', 'ExceptionType = exceptionType;', 'ExceptionType = exceptionType ?? typeof(Exception).FullName;')]),
    ('wrong-blank-fallback', ephemeral, [('failure', '"The step failed without an exception message."', '"Wrong detached fallback."')]),
    ('drop-wrapper-inner', ephemeral, [('facade', 'has no successful output.", originalException)', 'has no successful output.")')]),
]

def execute(name, suite):
    project, filter = suite
    destination = repo / '.artifacts/publishing-validation/runtime-mutations-reviewed' / name
    destination.mkdir(parents=True, exist_ok=True)
    log = out / ('mutation-' + name + '.log')
    command = ['dotnet', 'test', f'tests/OrcaCore.{project}.Tests/OrcaCore.{project}.Tests.csproj',
               '-c', 'Release', '--no-restore', '--filter', 'FullyQualifiedName~' + filter,
               '--logger', 'trx', '--results-directory', str(destination)]
    start = time.monotonic()
    try:
        with log.open('wb') as output:
            process = subprocess.Popen(command, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
            try:
                process.wait(timeout=60)
            except subprocess.TimeoutExpired:
                subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                raise
            result = process
    except subprocess.TimeoutExpired:
        return dict(id=name, outcome='Timeout', seconds=round(time.monotonic()-start, 2), command=command)
    files = list(destination.glob('*.trx'))
    counters = None
    if files:
        counters = ET.parse(files[-1]).find('.//{*}Counters').attrib
    text = log.read_text(encoding='utf-8', errors='replace')
    if not counters:
        outcome = 'CompileError' if 'error CS' in text or 'error xUnit' in text else 'HarnessError'
    elif int(counters['total']) == 0:
        outcome = 'Uncovered'
    else:
        outcome = 'Killed' if int(counters['failed']) > 0 else 'Survived'
    return dict(id=name, outcome=outcome, exitCode=result.returncode, counters=counters,
                seconds=round(time.monotonic()-start, 2), command=command, log=log.name)

results = []
try:
    for name, suite, edits in mutants:
        for edit in edits: replace(*edit)
        row = execute(name, suite)
        results.append(row)
        print(name + ': ' + row['outcome'], flush=True)
        for key, data in originals.items(): (repo / products[key]).write_bytes(data)
finally:
    for key, data in originals.items(): (repo / products[key]).write_bytes(data)
    restored = all((repo / products[key]).read_bytes() == data for key, data in originals.items())
    record = dict(scope='22 targeted product-source semantic mutations; not exhaustive Stryker coverage',
                  results=results, exactRestoration=restored,
                  uninstrumentedCoverage='Uncovered identifies an empty selected test run, not per-mutant coverage instrumentation',
                  originalSourceSha256={products[key]: hashlib.sha256(data).hexdigest() for key, data in originals.items()})
    (out / 'runtime-mutations.json').write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8', newline='\n')
assert restored
print(json.dumps({kind: sum(row['outcome']==kind for row in results) for kind in ['Killed','Survived','Timeout','CompileError','Uncovered','HarnessError']}), flush=True)
