from pathlib import Path
import subprocess, json, time, xml.etree.ElementTree as ET
root=Path('E:/oc16s')
out=root/'.artifacts/publishing-validation/final-validation'
out.mkdir(exist_ok=True)
rows=[]
def run(name,command,timeout=300):
    start=time.monotonic()
    with (out/(name+'.log')).open('wb') as log:
        result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
    row=dict(name=name,command=command,exitCode=result.returncode,seconds=round(time.monotonic()-start,2))
    destination=out/name
    trx=list(destination.glob('*.trx')) if destination.exists() else []
    if trx: row['counters']=ET.parse(trx[-1]).find('.//{*}Counters').attrib
    rows.append(row)
    (out/'lanes.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(name,result.returncode,row.get('counters',''),flush=True)
    if result.returncode: raise RuntimeError(name+' failed; see compact log')

run('build',['dotnet','build','OrcaCore.slnx','-c','Release','--no-restore','-warnaserror'])
for project in ['Core.Tests','Engine.Ephemeral.Tests','Engine.Durable.Tests','Acceptance.Tests','Hosting.Tests','ProviderCertification']:
    name='OrcaCore.'+project
    run(name,['dotnet','test',f'tests/{name}/{name}.csproj','-c','Release','--no-build','--no-restore','--collect:XPlat Code Coverage','--logger','trx','--results-directory',str(out/name)])
name='Infrastructure'
run(name,['dotnet','test','tests/OrcaCore.DeveloperSurface.Guards/OrcaCore.DeveloperSurface.Guards.csproj','-c','Release','--no-build','--no-restore','--filter','Disposition=Infrastructure','--collect:XPlat Code Coverage','--logger','trx','--results-directory',str(out/name),'--','DataCollectionRunSettings.DataCollectors.DataCollector.Configuration.Include=[OrcaCore.Engine.*]*'],timeout=600)
run('coverage',[str(root/'.artifacts/publishing-validation/tools/reportgenerator.exe'),'-reports:'+str(out/'**/coverage.cobertura.xml'),'-targetdir:'+str(out/'coverage-report'),'-reporttypes:Cobertura;MarkdownSummaryGithub','-assemblyfilters:+OrcaCore.Engine.*'])
coverage=ET.parse(out/'coverage-report/Cobertura.xml').getroot().attrib
(out/'coverage.json').write_text(json.dumps(coverage,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Complete CI engine coverage:',coverage,flush=True)
assert float(coverage['line-rate'])>=.75
for suffix in ['Providers.SqlServer.Tests','Providers.PostgreSql.Tests','Integration.Tests']:
    name='OrcaCore.'+suffix
    run(name,['dotnet','test',f'tests/{name}/{name}.csproj','-c','Release','--no-build','--no-restore','--logger','trx','--results-directory',str(out/name)],timeout=600)
run('benchmark-smoke',['dotnet','run','--project','benchmarks/OrcaCore.Benchmarks/OrcaCore.Benchmarks.csproj','-c','Release','--no-build','--no-restore','--','--smoke'])
run('openspec',['cmd','/c','openspec','validate','--all','--strict'])
run('native-gate-negatives',['python','-B','-m','unittest','discover','-s','tools/ephemeral-native-assessment/support_v2','-p','test_*.py'])
run('release-gate-negatives',['python','-B','-m','unittest','discover','-s','eng','-p','test_*.py'])
