from pathlib import Path
import subprocess, json, re, hashlib, collections, zipfile, xml.etree.ElementTree as ET
from urllib.parse import urljoin, urlparse, unquote

root=Path(__file__).resolve().parents[3]
scratch=Path(__file__).parent
validation=Path('E:/oc16s/.artifacts/publishing-validation')
art=root/'openspec/changes/expose-ephemeral-failures-and-settlement/artifacts'
def read(path): return json.loads(path.read_text(encoding='utf-8'))
def write(path,value): path.write_text(value,encoding='utf-8',newline='\n')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=root).decode()

mutations=read(scratch/'runtime-mutation-reviewed/runtime-mutations.json')
assert mutations['exactRestoration'] and all(row['outcome']=='Killed' for row in mutations['results'])
assert all(sha(root/name)==digest for name,digest in mutations['originalSourceSha256'].items())
native=read(validation/'frozen-package-preflight/support-report.json')
assert len(native['cases'])==84 and all(row['outcome']=='Passed' for row in native['cases'])
assert all(sha(root/name)==digest for name,digest in {**native['sourceFiles'],**native['harnessFiles']}.items())
stress=read(validation/'stress-frozen/stress.json')
assert len(stress['runs'])==20 and all(row['exitCode']==0 and row['counters']['passed']=='405' for row in stress['runs'])
coverage=ET.parse(validation/'frozen-coverage-report/Cobertura.xml').getroot().attrib
assert float(coverage['line-rate'])>=.75
lanes=read(validation/'final-validation/lanes.json')
lanes=[row for row in lanes if row['name'] not in ['OrcaCore.Engine.Ephemeral.Tests','Infrastructure','coverage','release-gate-negatives']]
for name,folder in [('OrcaCore.Engine.Ephemeral.Tests','frozen-ephemeral-coverage'),('Infrastructure','frozen-infrastructure')]:
    trx=next((validation/folder).glob('*.trx'))
    counts=ET.parse(trx).find('.//{*}Counters').attrib
    assert counts['failed']=='0'
    lanes.append(dict(name=name,exitCode=0,counters=counts,evidence=folder))
assert all(row['exitCode']==0 for row in lanes)

changed={};name=None
for line in git('diff','--unified=0','HEAD','--','*.cs').splitlines():
    if line.startswith('+++ b/'): name=line[6:];changed[name]=set()
    elif line.startswith('@@') and name:
        match=re.search(r'\+(\d+)(?:,(\d+))?',line);start=int(match[1]);count=int(match[2] or 1)
        changed[name].update(range(start,start+count))
for name in git('ls-files','--others','--exclude-standard','--','*.cs').splitlines():
    changed[name]=set(range(1,len((root/name).read_text(encoding='utf-8').splitlines())+1))
reports=[];introduced={}
for filename in ['source-reviewed.sarif','last-controls-consumers.sarif']:
    path=validation/'resharper'/filename
    doc=read(path);totals=collections.Counter()
    for run in doc['runs']:
        for item in run.get('results',[]):
            level=item.get('level','note');totals[level]+=1
            for loc in item.get('locations',[]):
                physical=loc['physicalLocation'];uri=physical['artifactLocation']
                base=run['originalUriBaseIds'][uri.get('uriBaseId','solutionDir')]['uri']
                absolute=Path(unquote(urlparse(urljoin(base,uri['uri'])).path).lstrip('/')).resolve()
                if absolute.is_relative_to(Path('E:/oc16s')): relative=absolute.relative_to(Path('E:/oc16s')).as_posix()
                elif absolute==Path('E:/oc16durable/Program.cs'): relative='tools/failure-settlement-consumer/Program.cs'
                else: continue
                line=physical['region']['startLine']
                if level=='warning' and line in changed.get(relative,set()):
                    introduced[(relative,line,item['ruleId'])]=item['message']['text']
    assert totals['error']==0
    reports.append(dict(path=filename,version='2026.2.3.1',configuration='Release',platform='Any CPU',targetFramework='net10.0',noBuild=True,counts=dict(totals),sha256=sha(path)))

reasons={
 'AccessToDisposedClosure':'The production cancellation scope is reference-counted across the physical task; disposal closes admission and physical/callback ownership delays final disposal. The test helper invokes its captured delegates synchronously before leaving its using scope. Existing timeout, callback, GC and settlement barriers exercise these boundaries.',
 'DisposeOnUsingVariable':'Explicit early Dispose is intentional in a control proving the completed receipt remains passive after owner disposal; repeated disposal is supported.',
 'SuspiciousTypeConversion.Global':'DispatchProxy creates the implementing runtime subtype; the armed provider proxy test executes successfully and verifies zero provider calls.',
 'RedundantCast':'The explicit DispatchProxy cast documents its runtime-generated intersection type.',
 'NotAccessedPositionalProperty.Local':'The property is serialized into the stored-byte witness and must remain in the state shape.',
 'InconsistentNaming':'Private field spelling follows the surrounding files; the test proxy interface is internal test scaffolding.',
}
triage=['# Task 3 ReSharper triage — 2026-11-02','',
 'InspectCode 2026.2.3.1; Release, **Any CPU**, net10.0, compatible builds and --no-build. No settings suppression or automatic cleanup was applied. The full changed solution-file report is supplemented by the final changed test and actual consumer projects in a private solution; the supplemental report supersedes earlier locations in those files. Raw SARIF is retained in the evidence archive.','',
 'Both final reports contain zero errors. Counts below are per report, not a deduplicated global total.','']
for row in reports: triage.append(f"- {row['path']}: {row['counts']}")
triage += ['', 'Every warning touching an added/changed line is listed below. Existing style suggestions are not a runtime defect or a claim of a warning-free codebase.','', '| Location | Rule | Disposition |','|---|---|---|']
for (name,line,rule),message in sorted(introduced.items()):
    reason=reasons.get(rule,'Retained nonbehavioral style/redundancy suggestion; no source or assertion is relaxed. Codec state, deliberate qualification and test clarity remain explicit.')
    triage.append(f'| `{name}:{line}` | `{rule}` | {reason} |')
triage += ['', 'Setup attempts are preserved separately: standalone NativeMetadata initially lacked references, and one private-solution include pattern selected no files. Neither is counted as successful analysis. A rebuild overlapping PostgreSQL produced a file-lock failure; the serialized final build is green. The empty eng Python discovery was a harness mistake; the real combined support/release gate directory passes 15/15.','']
write(art/'task-3-resharper-triage-2026-11-02.md','\n'.join(triage))

auth=read(art/'task-3-source-authorization-2026-11-02.json')
record=dict(stage='LocalValidatedAwaitingNativeQualificationAndIndependentApproval',base=git('rev-parse','HEAD').strip(),sourceApproval=None,
    canonicalCheckpoint=auth['canonicalCheckpoint'],canonicalVerdictCommit=auth['canonicalVerdictCommit'],
    productPaths=18,publicAdditions=['WorkflowFailure.ExceptionType','WorkflowInstanceHandle.WaitForSettlementAsync(CancellationToken = default)'],
    lanes=lanes,unitTotal=1043,coverage=coverage,stress=dict(runs=20,concurrency=2,testsPerRun=405,path='dotnet test',allGreen=True),
    mutations=dict(scope=mutations['scope'],counts=dict(collections.Counter(row['outcome'] for row in mutations['results'])),exactRestoration=True,
        finalProductionHashesStillMatch=True,testOnlyAdditionsAfterCampaign='Four extra root/recovery cases strengthen the same tests; no assertion was weakened.'),
    resharper=reports,provenance=dict(rows=218,pending=0,sha256='f6e5ed0ad28a597fbbea17a62a10c9cfd6e05f580e0051f62f51d558d7a24783',predecessors=28,unchanged=True),
    testInventory=dict(physicalFiles=374,physicalDeclarations=1535,activeFiles=218,activeDeclarations=847,unchangedRetiredRows=866),
    publicPackagePreflight=dict(cases=84,passed=84,protocol=4,host=native['host'],packageDllsVerified=True,sourceAndHarnessHashesMatch=True,
        generatedFailureTypes=native['failureTypes'],legacyFailureTypes=native['legacyFailureTypes'],expectedQualificationError='Unqualified native host',nativeQualification=False),
    durableConsumer=read(Path('E:/oc16durable/result.json')),
    nativeSixCells=dict(completed=0,required=6,expectedCases=392,approval=None,pushAuthorized=False),
    previousFailures=['Initial mutation harness locked DLLs; excluded outcomes retained. Final 22-mutation campaign has zero other outcomes.',
        'Stress 19/20 exposed the existing cooperative-shutdown test race, fixed by physical-exit barrier. Final expanded suite is 20/20.',
        'Speculative nested-branch composition and direct Core-internal probes did not compile; neither is behavior-red evidence.',
        'Rebuild/provider overlap was a file-lock setup error; serialized final build passes. Empty eng test discovery was replaced by real 15-test combined gate.'],
    authority='No source checkpoint, push, PR, issue change, merge, archive or release; all task 3 checkboxes remain open.')
write(art/'task-3-validation-2026-11-02.json',json.dumps(record,indent=2)+'\n')

archive=art/'task-3-evidence-2026-11-02.zip'
selected={}
def add(directory,prefix):
    for path in directory.rglob('*'):
        if path.is_file() and path.suffix.lower() in ['.json','.log','.trx','.xml','.md','.txt','.csv','.sarif','.py','.zip'] and not any(part in ['bin','obj','packages','cache'] for part in path.relative_to(directory).parts):
            selected[prefix+'/'+path.relative_to(directory).as_posix()]=path
for folder in ['final-validation','frozen-ephemeral-coverage','frozen-infrastructure','frozen-coverage-report','stress-frozen','frozen-package-preflight']:
    add(validation/folder,'final/'+folder)
for name in ['source-reviewed.sarif','last-controls-consumers.sarif','consumer.sarif']:
    selected['resharper/'+name]=validation/'resharper'/name
for path in validation.glob('*.log'): selected['validation-logs/'+path.name]=path
add(scratch,'preparation-and-mutations')
for name in ['result.json','command-0.log','command-1.log']:
    selected['durable-consumer/'+name]=Path('E:/oc16durable')/name
selected['earlier-stress/stress.json']=validation/'stress-final/stress.json'
for path in (validation/'stress-final/18').glob('*.trx'): selected['earlier-stress/'+path.name]=path
selected['earlier-stress/18.log']=validation/'stress-final/18.log'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for name,path in sorted(selected.items()): output.write(path,name)
    output.writestr('evidence-index.json',json.dumps({name:dict(bytes=path.stat().st_size,sha256=sha(path)) for name,path in sorted(selected.items())},indent=2)+'\n')
with zipfile.ZipFile(archive) as output: assert output.testzip() is None
print(json.dumps(dict(lanes=len(lanes),unitTotal=1043,coverage=coverage['line-rate'],introducedWarningLocations=len(introduced),archiveBytes=archive.stat().st_size,archiveFiles=len(selected)),indent=2))
