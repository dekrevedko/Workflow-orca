from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess, json, time, xml.etree.ElementTree as ET

root = Path('E:/oc16s')
output = root / '.artifacts/publishing-validation/stress-frozen'
output.mkdir(exist_ok=True)

def run(number):
    destination = output / str(number)
    destination.mkdir()
    command = ['dotnet','test','tests/OrcaCore.Engine.Ephemeral.Tests/OrcaCore.Engine.Ephemeral.Tests.csproj',
               '-c','Release','--no-build','--no-restore','--logger','trx','--results-directory',str(destination)]
    with (output / (str(number)+'.log')).open('wb') as log:
        result = subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=90)
    files = list(destination.glob('*.trx'))
    counters = ET.parse(files[0]).find('.//{*}Counters').attrib if files else None
    return dict(run=number,exitCode=result.returncode,counters=counters)

records=[]
with ThreadPoolExecutor(max_workers=2) as pool:
    for row in pool.map(run,range(1,21)):
        records.append(row)
        print('Run',row['run'],'exit',row['exitCode'],row['counters'],flush=True)
record=dict(commandPath='dotnet test, unfiltered Release, no-build/no-restore',concurrency=2,runs=records)
(output/'stress.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
assert all(row['exitCode']==0 and row['counters']['failed']=='0' and row['counters']['passed']=='405' for row in records)
