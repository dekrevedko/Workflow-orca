from pathlib import Path
import subprocess, re, json, collections
root=Path(__file__).resolve().parents[3]
diff=subprocess.check_output(['git','diff','--unified=0','HEAD','--','*.cs'],cwd=root).decode()
changed={};name=None
for line in diff.splitlines():
    if line.startswith('+++ b/'): name=line[6:];changed[name]=set()
    elif line.startswith('@@') and name:
        match=re.search(r'\+(\d+)(?:,(\d+))?',line)
        start=int(match[1]);count=int(match[2] or 1)
        changed[name].update(range(start,start+count))
for name in subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','*.cs'],cwd=root).decode().splitlines():
    changed[name]=set(range(1,len((root/name).read_text(encoding='utf-8').splitlines())+1))
results=json.loads(Path('E:/oc16s/.artifacts/publishing-validation/resharper/source-final.sarif').read_text())['runs'][0]['results']
hits=[dict(rule=x['ruleId'],level=x.get('level'),location=x['locations'][0]['physicalLocation'],message=x['message']['text'])
      for x in results if any(y['physicalLocation']['region']['startLine'] in changed.get(y['physicalLocation']['artifactLocation']['uri'],set()) for y in x['locations'])]
Path(__file__).with_name('resharper-changed-lines.json').write_text(json.dumps(hits,indent=2)+'\n',encoding='utf-8',newline='\n')
print(collections.Counter(x['level'] for x in hits))
for x in hits:
    if x['level']=='warning':print(x['level'],x['rule'],x['location']['artifactLocation']['uri'],x['location']['region']['startLine'],x['message'])
